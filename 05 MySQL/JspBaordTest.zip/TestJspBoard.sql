use my_cat;

select*from cat_board;
select * from member;
create table cat_board(
	num int primary key auto_increment, 
    title char(255),
    content text,
    id char(30)
    );
    
    insert into cat_baord values (0, '테스트1', '테스트 내용1','cat');
    insert into cat_baord values (0, '테스트2', '테스트 내용2','dog');
    
    drop table cat_baord;