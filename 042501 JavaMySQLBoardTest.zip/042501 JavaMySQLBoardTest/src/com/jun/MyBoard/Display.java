package com.jun.MyBoard;

public class Display {
	static private String Title_Bar = "😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺😺";
	static private String Title = "😺😺😺😺😺😺😺😺😺😺😺😺     게시판     😺😺😺😺😺😺😺😺😺😺😺😺";

	static private String Main_Menu_Bar = "================================================================";
	static private String Main_Menu = "(1)글목록 (2)글읽기 (3)글쓰기 (4)글삭제 (0)관리자 (x)프로그램종료";

	static public void showTitle() {
		System.out.println(Title_Bar); //
		System.out.println(Title);
		System.out.println(Title_Bar);
	}

	static public void showMainMenu() {
		System.out.println(Main_Menu_Bar);
		System.out.println(Main_Menu);
		System.out.println(Main_Menu_Bar);
	}
}
