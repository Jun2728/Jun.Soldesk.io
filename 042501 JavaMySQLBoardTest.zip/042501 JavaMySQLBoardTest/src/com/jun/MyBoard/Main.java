package com.jun.MyBoard;

public class Main {
	public static void main(String[] args) {
		ProcBoard ProcBoard = new ProcBoard();
		ProcBoard.run();
	} 
	//main->컨트롤 스페이스로 public static void main(String[] args) 자동생성
}
