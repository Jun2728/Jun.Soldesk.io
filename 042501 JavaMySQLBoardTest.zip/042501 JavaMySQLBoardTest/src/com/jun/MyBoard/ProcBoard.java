package com.jun.MyBoard;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ProcBoard {
	Connection con = null; // DB 연결용
	Statement st = null; // SQL 실행용
	ResultSet result = null; // 결과 저장용
	Scanner sc = new Scanner(System.in); // 사용자 입력용

	void run() {
		Display.showTitle(); // 타이틀 출력
		dbInit(); // 데이터베이스 연결
		loop: while (true) {
			dbPostCount(); // 현재 글 수 보여주기
			Display.showMainMenu();
			System.out.println("명령을 입력해주세요:");
			String cmd = sc.next();
			switch (cmd) {
			case "1": // 글 목록
				System.out.println("==========================================");
				System.out.println("================= 글리스트 ==================");
				System.out.println("==========================================");
				System.out.println("글번호 글제목 작성자id 작성시간");
				try {
					result = st.executeQuery("select * from board");
					while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
						String no = result.getString("b_no");
						String title = result.getString("b_title");
						String id = result.getString("b_id");
						String datetime = result.getString("b_datetime");
						System.out.println(no + " " + title + " " + id + " " + datetime);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "2": // 글 읽기
				System.out.println("읽을 글 번호를 입력해주세요:");
				String readNo = sc.next();
				try {
					result = st.executeQuery("select * from board where b_no =" + readNo);
					result.next();
					String title = result.getString("b_title");
					String content = result.getString("b_text");
					System.out.println("글제목: " + title);
					System.out.println("글내용: " + content);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "3": // 글 쓰기
				sc.nextLine(); // 위에 sc.next() 쓴거 때문에 추가함.
				System.out.println("제목을 입력해주세요:");
				String title = sc.nextLine();
				System.out.println("글내용을 입력해주세요:");
				String content = sc.nextLine(); // 이거 전에는 쓸 필요 없음. 바로 전에서 쓰인건 nextLine() 이기 때문.
				System.out.println("작성자id를 입력해주세요:");
				String id = sc.next();
				try {
					st.executeUpdate("insert into board (b_title,b_id,b_datetime,b_text,b_hit)" + " values ('" + title
							+ "','" + id + "',now(),'" + content + "',0)");
					System.out.println("글등록 완료");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "4": // 글 삭제
				System.out.println("삭제할 글번호를 입력해주세요:");
				String delNo = sc.next();
				dbExecuteUpdate("delete from board where b_no=" + delNo);
				break;
			case "5": // 글 수정
				System.out.println("수정할 글번호를 입력해주세요:");
				String editNo = sc.next();
				System.out.println("제목을 입력해주세요:");
				sc.nextLine();
				String edTitle = sc.nextLine(); // << 여기에서 다시 정상적으로 쓰면됨.
				System.out.println("작성자id를 입력해주세요:");
				String edId = sc.next();
				System.out.println("글내용을 입력해주세요:");
				sc.nextLine(); // 위에 sc.next() 쓴거 때문에 추가함.
				String edContent = sc.nextLine();
				dbExecuteUpdate("update board set b_title='" + edTitle + "',b_id='" + edId
						+ "',b_datetime=now(),b_text='" + edContent + "' where b_no=" + editNo);
			case "0": // 관리자 메뉴
				// 없음
				break;
			case "e": // 프로그램 종료
				System.out.println("프로그램을 종료합니다.");
				break loop;
			}
		}
	}

	private void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root"); // DB 연결 (my_cat
																										// 데이터 베이스)
			st = con.createStatement(); // SQL 실행할 Statement 객체 생성
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query); // 삽입, 수정, 삭제 쿼리 실행
			System.out.println("처리된 행 수:" + resultCount); // 결과 출력
		} catch (SQLException e) {
			e.printStackTrace(); // 오류 발생 시 출력
		}
	}

	private void dbPostCount() {
		try {
			result = st.executeQuery("select count(*) from board");
			result.next();
			String count = result.getString("count(*)");
			System.out.println("글의 수:" + count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}