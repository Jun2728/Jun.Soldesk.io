function displayIntro(){
tv("
                                                                                                                                                   
                                                                                                                                                      
                 .P                                                                    .                                                              
                 q      v.                                                         .vYvP:                                                            
           rP    . .   qv                                                        Lsv.   q7                                                           
            :7 7vi7P7 ::                i5Jvjssr:.                             uq.       rP.                                                         
              71    Yr   .::          .Ss     .:rs1Ii                       iUSi           Pr                                                        
         ivvv u:    :U r7ri.         2S             X5                   rJ27.              LS                                                       
         .     q.  .d.             sK:               7g               .IXi                   :qr                                                     
              i.rrir  .          ibi                  .Q            .j5.                       YK                                                    
             K7   :   UY       :KY                     vP          jK:                          iD                        Pr                         
           .qi    Q    uI    i5U                        Bi      .jdr                             iZ                      d.7q                        
                 .D     iU YP7                           B    :5Pi                                7K                    D:  idr                      
                  .      5Zi                             rB .5j.                                   .Pr                .R:     rb.                    
                      .JP:                                qQi                                        72r             7d.        I1                   
                    7P1.                                   B                                           i5v.        :Mr           ig.                 
                  7Ms                                      .B                                            :uU.     7Q               Di                
                :R1                                         Lg                                             .SL.  iB                 vI:              
               Xd                                            1M                      ::ii..                  .  ug                    1X.            
              gs                                              Ug                  .uL:.:R:7vsL.               7M7                      .II.          
            .B:                                                YZ.                M.    5     g             YBJ                          .2u:        
           :R                                  i                .Ps              K:     K     77          sMs                               ivsr.    
          rE                                R  B                  Jg            :K      2      d       .udr                                    :7jLi 
          :                                .B  B:                  :Qi          si     iL .    K    :7UY:                                          :r
                                         :rs.71.7                    SK         v:    :BrIR    J    i.                                               
                                        :Es     ij                    :P.   777rq1r77rrrKis:i:.Zr:i                                                  
                                        ru        1L                                       ..:.PY..                                                  
                                        ED  viri:.iYi.                                                                                               
                                      viB. .g  ...r  rur                                                                                             
                                      rB:  K:     .s7  .sSY.                                                                                         
                                     q5I  rI        .YI.  :IP.                                                                                       
                                   irvB   D.           UI   .U2i                                                                                     
                       v2XB2r5PZ1qud7s.   E             id     75r                                                                                   
                     rBK:riiriS7:MJvs    I7              .gi     :u17.                                                                               
                     BI                vYr                 JS:      :L17.    :r.                                                                     
                  L g1                 D                     J5.       .7YYKJ..iL5::7rr                               Y                              
                  5BQ                  Y:                     .1J          :vi.   r.  .g.:v:                   .2.    ZB                             
                 2iB                   1i                       .bv          .rvLi.    .Pr.vIZLvj7:             .Ur   2r                             
              vivBi :RSK.       ..::::vQi                       .7.X:            .:r7Jj      .   .rj7             rBv.Bvi.                           
         7L.XvB57: .rXi7U.rgLZ7i:.:bJ5 vr:s.                    :q  :1.                             iB:           r.: 7. Bi                          
       .MBBbdsvi.i7.Ss.17:EBEj:7r   j J U rg                     .YsisX      LEv...:.              .S.               .B. :                           
                      ...  .r   7   r.i:                               :::i:7.  ... ..::::::r:...:ir                5  s                             

");                      
}