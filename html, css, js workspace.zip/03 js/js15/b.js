for (i=1; i<=3; i++){
    // if(i==2){
    //     continue;
    // } 2가 출력이 안됨됨
    document.write("<hr>")
    document.write(i);
}