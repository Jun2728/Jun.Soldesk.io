

window.onload = function(){

    var a = document.getElementById("a");
    a.innerHTML="고양이";

    
}

var x=1;