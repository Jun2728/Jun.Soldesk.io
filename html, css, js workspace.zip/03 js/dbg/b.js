var b = ["개", "고양이", "너구리"];

for (var i=0; i < b.length; i=i+1){
    document.write(b[i]);
}


