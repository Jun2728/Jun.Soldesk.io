
var a = 1;

function x(){
    document.write("야옹");
    document.write("야옹");
    document.write("야옹");
}



document.write(a)

x();

var b = 2;

document.write(b);

