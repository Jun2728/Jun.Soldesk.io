var a = 1;

if (a < 1){
    document.write("고양이");
} else if( a < 2){
    document.write("개");
} else {
    document.write("너구리");
}