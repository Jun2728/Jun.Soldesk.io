var a = 3;

switch (a) {
    case 1:
        document.write("당첨")
        break;
    case 2:
        document.write("당첨")
        break;
    case 3:
        document.write("당첨")
        break;
    default:
        document.write("참가상")
}