module Hello5 {
}