package com.jun.helloworld;

public class Main {
	public static void main(String[] args) {
		System.out.println("헬로 월드!!!");
	}

}
