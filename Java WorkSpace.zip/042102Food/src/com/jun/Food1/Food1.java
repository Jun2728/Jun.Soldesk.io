package com.jun.Food1;

public class Food1 {
	String name;
	boolean isHot;
	int price;

	public Food1(String name, boolean isHot, int price) {
		this.name = name;
		this.isHot = isHot;
		this.price = price;
	}
}