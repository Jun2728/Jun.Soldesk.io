package com.jun.Extends;

public class Sword extends Item {
	int attack;

}
