package com.jun.Extends;

public class Item extends GameObj {
//	String name;
	
	int weight;
	int 수명;
}
