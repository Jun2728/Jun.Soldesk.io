package com.jun.Extends;

public class Character extends GameObj{
//	String name;
	int hp;
	int attack;
	
}
