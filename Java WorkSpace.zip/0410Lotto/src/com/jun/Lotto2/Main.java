package com.jun.Lotto2;

public class Main {

	public static void main(String[] args) {
		Lotto2 lotto = new Lotto2();
		lotto.run();
	}

}
