package com.jun.Lotto3;

public class Main {

	public static void main(String[] args) {
		Lotto3 lotto = new Lotto3();
		lotto.run();
	}

}
