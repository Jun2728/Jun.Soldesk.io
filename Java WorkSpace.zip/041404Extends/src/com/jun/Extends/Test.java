package com.jun.Extends;

public class Test {
	
	public static void main(String[]args) {
		
		int a;
		long b = 214783648L;
		
		a=(int)b;
		System.out.println(a);
	}

}
