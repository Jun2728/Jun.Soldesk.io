package com.jun.Class2;

public class Main {

	public static void main(String[]args) {
		
//		Dice x = new Dice();
	
		
		System.out.println(Dice.a);

		
	}
	
}
