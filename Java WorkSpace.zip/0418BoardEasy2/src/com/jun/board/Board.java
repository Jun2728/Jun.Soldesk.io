package com.jun.board;

import java.util.ArrayList;
import java.util.Scanner;

public class Board {
	Scanner sc = new Scanner(System.in);
	ArrayList<Post> ps = new ArrayList<>();
	int postNo = 0;

	void run() {
		System.out.println("간단 게시판 ver.1.03");
		while (true) {
			System.out.println("메뉴를 선택하세요");
			System.out.println("1.작성 2.읽기 3.리스트 4.수정 5.삭제 e.프로그램 종료");

			String cmd = sc.next(); // 사용자 명령 입력

			switch (cmd) {
			case "1":
				System.out.println("==== 글쓰기 ====");
				sc.nextLine();
				System.out.print("제목: ");
				String t = sc.nextLine();
				System.out.print("본문: ");
				String c = sc.nextLine();
				System.out.print("작성자: ");
				String w = sc.nextLine();

				postNo = postNo + 1;
				Post p = new Post(t, c, w, postNo);
				ps.add(p);

				System.out.println("글 작성 완료");
				break;

			case "2":
				System.out.println("==== 글 읽기 ====");
				System.out.print("몇 번 글을 읽을까요? ");
				cmd = sc.nextLine();

				boolean foundRead = false;
				// boolean 써보기

				for (Post post : ps) { //for each문 활용
					String postStringNo = post.no + "";
					if (postStringNo.equals(cmd)) {
						System.out.println("글번호: " + post.no);
						System.out.println("제목: " + post.title);
						System.out.println("내용: " + post.content);
						System.out.println("작성자: " + post.writer);
						foundRead = true;
						break;
					}
				}
				if (!foundRead) {
					System.out.println("존재하지 않는 글입니다.");
				}
				break;

			case "3":
				System.out.println("==== 글 목록 ====");
				for (Post post : ps) {
					System.out.println("글번호: " + post.no + " 제목: " + post.title + " 내용: " + post.content + " 작성자: " + post.writer);
				}
				System.out.println("==== ==== ====");
				break;

			case "4":
				System.out.println("==== 글 수정 ====");
				System.out.print("몇 번 글을 수정할까요? ");
				cmd = sc.next();

				boolean foundRevise = false;
				sc.nextLine();


				for (Post post : ps) {
					String postStringNo = post.no + "";
					if (postStringNo.equals(cmd)) {
						System.out.print("수정할 내용 입력: ");
						post.content = sc.nextLine(); // 띄어쓰기 포함한 입력 받기 sc.next는 띄어쓰기 이후 안됨
						System.out.println("내용이 수정되었습니다.");
						foundRevise = true;
						break;						
					}
				}
				if (!foundRevise) {
					System.out.println("존재하지 않는 번호입니다.");
				}
				break;

			case "5":
				System.out.println("==== 글 삭제 ====");
				System.out.print("몇 번 글을 삭제할까요? ");
				cmd = sc.next();

				boolean foundDelete = false;

				for (int i = 0; i < ps.size(); i=i+1) {
					Post post = ps.get(i);
					String postStringNo = post.no + "";
					if (postStringNo.equals(cmd)) {
						ps.remove(i); // 해당 글 삭제
						System.out.println("글이 삭제되었습니다.");
						foundDelete = true;
						break;
					}
				}
				if (!foundDelete) {
					System.out.println("존재하지 않는 번호입니다.");
				}
				
				break;

			case "e":
				System.out.println("프로그램을 종료합니다.");
				return;
				
			default:
				System.out.println("잘못된 입력입니다. 메뉴로 돌아갑니다.");
				break;
			}
		}
	}
}