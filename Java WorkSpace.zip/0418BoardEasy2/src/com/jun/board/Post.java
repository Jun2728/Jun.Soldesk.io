package com.jun.board;

public class Post {
	int no;
	String title;
	String content;
	String writer;
	
	public Post(String t, String c, String w, int postNo) {
		title = t;
		content = c;
		writer = w;
		no = postNo;
	}
public String toString() {
	return String.format("글번호: %s 제목: %s 작성자: %s", no, title, writer);
}

void infoForRead() {
	String s  = String.format("글번호: %s 제목: %s 작성자: %s", no, title, writer);
	System.out.println("================================================");
	System.out.println(s);
	System.out.println("================================================");
	System.out.println(content);
	System.out.println("================================================");
}


// 참고: getㅇㅇㅇ setㅁㅁㅁ 함수 자동 생성하는법
// 현재 편집창에서 마우스우클릭-소스-제너레이트 게터세터
// -자동으로 생성하고 싶은 멤버변수들 체크하고 엔터. 끝.
public int getNo() {
	return no;
}

public void setNo(int no) {
	this.no = no;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getContent() {
	return content;
}

public void setContent(String content) {
	this.content = content;
}

public String getWriter() {
	return writer;
}

public void setWriter(String writer) {
	this.writer = writer;
}	
}