package com.jun.board;

import java.util.ArrayList;
import java.util.Scanner;

public class Board {
	Scanner sc = new Scanner(System.in);
	ArrayList<Post> ps = new ArrayList<>();
	int saveNo = 0;
	
	void run() {
		xx:while(true) {
			//메뉴 선택하게 하기
			System.out.println("crud 1.쓰기 2.읽기 3.리스트 4.수정 5.삭제 e.프로그램 종료");
			String cmd = sc.next();
			switch(cmd) {
			case "1":
				System.out.println("쓰기");
				System.out.println("제목:");
				String title = sc.next();
				System.out.println("본문:");
				String content = sc.next();
				System.out.println("작성자:");
				String writer = sc.next();
				saveNo = saveNo + 1;
				Post p = new Post(title,content,writer,saveNo);
				ps.add(p);
				break;
			case "2":
				//몇 번 글을 읽을지 물어보기
				System.out.println("몇 번글을 읽을까요?");
				cmd = sc.next(); //위에서 String cmd를 썼으니 cmd만 써도 됨
				
				//해당 글을 찾기
				for (Post post : ps) { //for each문으로 더 간략하게
					String postStringNo = post.no + ""; // 이부분gpt에 물어보자 string과 int 변환
					if(postStringNo.equals(cmd)) { //찾았다!
						//읽기(출력)
						System.out.println("글번호:"+post.no+"내용:"+post.content+"작성자:"+post.writer);
					}
				}
//				System.out.println("읽기");
				break;
			case "3":
				System.out.println("리스트");
//				for(int i=0;i<ps.size();i++) = 	for(int i=0;i<ps.size();i=i+1) 
				for(Post post : ps) {
					System.out.println("글번호:"+post.no+"제목: "+post.title+" 내용:"+post.content+"작성자: "+post.writer);
				}
				break;
			case "4":
				System.out.println("수정");
				//수정할 글 번호 입력 받기
				System.out.println("몇 번글을 수정할까요?");
				cmd = sc.next();
				//해당 글 가져오기
				for(Post post : ps) {
					String postStringNo = post.no+"";
					if(postStringNo.equals(cmd)) {//찾았다.
						System.out.println("수정할 내용은?");
						
						//String newContent = sc.next();
						//post.content = newContent;
						post.content = sc.next(); //새 내용 덮어쓰기
								
					}
				}
				break;
			case "5":
				System.out.println("삭제");
				
				//삭제할 글 번호 입력 받기
				System.out.println("몇 번글을 지울까요?:");
				cmd = sc.next();
				
				//글 리스트에서 삭제할 글 찾기
				int searchNo = 0;
				//해당 글을 찾기
				for(int i=0;i<ps.size();i=i+1) {
					Post post = ps.get(i);
					String postStringNo = post.no + "";
					if(postStringNo.equals(cmd)) { //찾았다!						
						//인덱스 i를 기억해놓기
						searchNo = i;
					}
				}
				//삭제
				ps.remove(searchNo);
				
				break;
			case "e":
				System.out.println("프로그램종료");
				break xx;
			}
		}
	}
}
