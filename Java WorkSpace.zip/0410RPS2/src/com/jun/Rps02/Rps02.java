package com.jun.Rps02;

import java.util.Scanner;

public class Rps02 {
	void run() {
		Scanner sc = new Scanner(System.in);
		int r = 0;
		String cmd ="";
		String result="";
		
		xx:
			while(true) {
				System.out.println("가위바위보 게임을 시작하겠습니다. [종료는 X버튼을 입력.]:");
				cmd = sc.next();
				r = (int)(Math.random()*3+1);
				switch(cmd) {
				case "가위":
					switch(r) {
					case 1:
						result="Draw";
						break;
					case 2:
						result="Lose";
						break;
					case 3:
						result="Win";
						break;
					}
					break;
					
				case "바위":
					switch(r) {
					case 1:
						result="Win";
						break;
					case 2:
						result="Draw";
						break;
					case 3:
						result="Lose";
						break;
					}
					break;
					
				case "보":
					switch(r) {
					case 1:
						result="Lose";
						break;
					case 2:
						result="Win";
						break;
					case 3:
						result="Draw";
						break;
					}
					break;
				case"x":
					break xx;
				}
System.out.println(result);
			}
		System.out.println("프로그램이 종료됩니다.");
	}


}
