package com.jun.Rps02;

public class Main02 {
	public static void main(String[] args) {
		Rps02 rps02 = new Rps02();
		rps02.run();
	}
}