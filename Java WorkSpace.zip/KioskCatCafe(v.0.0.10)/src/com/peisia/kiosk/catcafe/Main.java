package com.peisia.kiosk.catcafe;

import com.peisia.util.Color;

public class Main {

	public static void main(String[] args) {
		
		Color.sum(Color.BRIGHT_PURPLE, "고양이");
		Color.test("고양이");
		Color.bold("고양이");
		
		
		Kiosk k = new Kiosk();
		k.run();
	}
}
