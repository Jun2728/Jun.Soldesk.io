package com.peisia.kiosk.catcafe.product;

public class Dessert extends Product{

	public Dessert(String xx, int yy) {
		super(xx, yy);
	}

}
