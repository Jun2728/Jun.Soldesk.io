package com.jun.Singleton;

import java.util.ArrayList;

public class FinalBoss {
// 1. 생성자를 private로 생성
	private FinalBoss(){
		System.out.println("최종보스 등장");
	}
// 2. 클래스 내부에 private static 변수로 '유일'한 인스턴스 생성
		ArrayList<String> s = new ArrayList<>();
// Array List<String>s;

	private static FinalBoss f = new FinalBoss();

// 3. 유일한 인스턴스를 반환하는 public static 메서드를 제공
	public static FinalBoss getInstance() {
		return f;
	}

	void y() {

	}
}