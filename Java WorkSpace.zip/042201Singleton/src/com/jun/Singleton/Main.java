package com.jun.Singleton;

public class Main {

	public static void main(String[]args) {
		
		FinalBoss f = FinalBoss.getInstance();
		f.y();
	}
}
