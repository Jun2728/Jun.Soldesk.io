package com.jun.stringcopy;

public class Main {

	public static void main(String[] args) {

		String cat = "예제";	

		
		String cat2 = "예제";
		
		if(cat == cat2) {
			System.out.println("같음");
			System.out.println(System.identityHashCode(cat));
			System.out.println(System.identityHashCode(cat2));

		}
		
		String dog = new String("예제2");	
		String dog2 = new String("예제2");	
		if(dog == dog2) {
			System.out.println("같음");
		} else {
			System.out.println("다름");
		}
		System.out.println(System.identityHashCode(dog));
		System.out.println(System.identityHashCode(dog2));
		
		if(dog.equals(dog2)) {
			System.out.println("문자열 같음");
		} else {
			System.out.println("문자열 다름");
		}
	}
}

