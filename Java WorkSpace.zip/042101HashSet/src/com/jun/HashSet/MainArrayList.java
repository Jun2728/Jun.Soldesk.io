package com.jun.HashSet;

import java.util.ArrayList;
import java.util.Iterator;

public class MainArrayList {

    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("고양이");
        list.add("고양이");
        list.add("개");
        
        int size = list.size();
        System.out.println(size); // 3
        
        Iterator<String> it = list.iterator();
        System.out.println("-while, next() 으로 꺼내기-");
        while (it.hasNext()) {
            String s1 = it.next();
            System.out.println(s1);
        }
    }
}