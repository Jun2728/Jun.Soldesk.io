package com.jun.cat;

public class Cat {

	String name;
	int age;
	String color;

	public Cat() {
		System.out.println("고양이 탄생!");
	}

	public Cat(String name, int age) {
		this.name = name;
		this.age = age;

	}

	void eat(String food, String name, String need, int a) {
		System.out.println(name + "이(가)" + food + "을(를)" + "먹네요");

	}

	String run() {
		System.out.println("달리는 중");
		return "야옹";
	}

	void bread() {
		System.out.println("식빵을 굽는 중");
	}
}
