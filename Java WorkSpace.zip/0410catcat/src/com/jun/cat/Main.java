package com.jun.cat;

public class Main {
	public static void main(String[]args) {
		
		Cat cat = new Cat();
		cat.name = "도라에몽";
		cat.age = 10;
		
		Cat cat2 = new Cat("야옹이", 7);
		
		cat.eat("단팥빵", "츄르", "우유", 3);
	}
}
