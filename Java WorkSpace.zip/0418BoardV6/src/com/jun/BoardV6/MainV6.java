package com.jun.BoardV6;

public class MainV6 {
	public static void main(String[] args) {
		
		BoardV6 b = new BoardV6();
		b.run();
	}

}
