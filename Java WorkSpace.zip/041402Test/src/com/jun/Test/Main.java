package com.jun.Test;

public class Main {
	public static void main(String[] args) {
		
		int a = 1;
		System.out.println(a);
		
		int b = 1;
		System.out.println(b);
	}
}
