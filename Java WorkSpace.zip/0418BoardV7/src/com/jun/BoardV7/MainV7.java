package com.jun.BoardV7;

import com.jun.BoardV7.BoardV7;

public class MainV7 {
	public static void main(String[] args) {
		
		BoardV7 b = new BoardV7();
		b.run();
	}

}
