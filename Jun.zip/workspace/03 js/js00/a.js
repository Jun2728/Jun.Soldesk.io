// 이거 주석임. 한줄 주석.

/*
    참고: 여러줄 주석은 이렇게
    dfas
    asfasdf
    afasdfsa

*/

// <script src="a.js"> </script> 에 의해
// 프로그램 해석기가 여기로 와서 아래로 한줄 한줄 읽으면서
// 처리하게 됨.

// alert 함수라고 하고 얘는 팝업을 띄워줌.
// ( 안에 쓴 내용을 찍음)
//명령문. 문. 마지막에 마침표를 찍어야함. ; 이 js의 명령문의 마침표임.   

/*
alert("Hello World");   
alert(1000);   
alert(1+7);   

*/

// alert("Hello World");   
// alert(1000);   
// alert(1+7);   

document.write("Hello World");