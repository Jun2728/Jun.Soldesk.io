var cat_house ="고양이";

var a = 1;

var b = 2;

var c = 5 + b;

document.write(c);