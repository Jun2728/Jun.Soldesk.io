/* 표현 1 */
// var random = Math.floor(Math.random() * 6) + 1; // 1 ~ n 까지 범위내에서 랜덤하게 숫자 하나 뽑아주는 애.
// var s = "주사위를 굴려 ( " + random + " ) 이 나왔습니다.";
// document.write(s);


/* 표현 2 */
// var random;
// random = Math.floor(Math.random() * 6) + 1; // 1 ~ n 까지 범위내에서 랜덤하게 숫자 하나 뽑아주는 애.
// document.write("주사위를 굴려 ( " + random + " ) 이 나왔습니다.");


/* 표현 3 */
// var random = Math.floor(Math.random() * 6) + 1; // 1 ~ n 까지 범위내에서 랜덤하게 숫자 하나 뽑아주는 애.
// document.write("주사위를 굴려 ( " + random + " ) 이 나왔습니다.");

/* 표현 4 */
// document.write("주사위를 굴려 ( " + (Math.floor(Math.random() * 6) + 1) + " ) 이 나왔습니다.");



/* 6면체 */
var r;
r = Math.floor(Math.random() * 6) + 1; // 1 ~ n 까지 범위내에서 랜덤하게 숫자 하나 뽑아주는 애.
var s = "주사위를 굴려 ( " + r + " ) 이 나왔습니다.";
document.write(s);

/* 4면체 */
var r2; 
r2 = Math.floor(Math.random() * 4) + 1; // 1 ~ n 까지 범위내에서 랜덤하게 숫자 하나 뽑아주는 애.
var s2 = "주사위를 굴려 ( " + r2 + " ) 이 나왔습니다.";
document.write(s2);

